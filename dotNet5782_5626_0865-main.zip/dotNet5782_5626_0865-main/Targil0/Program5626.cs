﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Targil0
{
    partial class Program
    {
        static partial void Welcome5626()
        {
            Console.WriteLine("i am also hear");
        }
    }
}
