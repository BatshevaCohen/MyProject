# dotNet5782_5626_0865
The project deals with the management of an information system of delivery service performed using drones,
the deliveries are made between the various customers of the service.
For example deliveries from different stores and businesses to different consumers.
The company maintains base stations for the maintenance and loading of the drones as well as information on customers and packages sent through the service.
The company that operates the delivery service monitors the delivery of the deliveries and also manages the monitoring of the maintenance of the drones.

# Signing in with manager password:
![image](https://user-images.githubusercontent.com/80363611/159012850-8d18be74-30db-4f9a-9fe6-f0343b6cb813.png)

# The main window:
![image](https://user-images.githubusercontent.com/80363611/159012865-28ba9b41-de7d-49fd-ad83-bf6bd82871ac.png)
