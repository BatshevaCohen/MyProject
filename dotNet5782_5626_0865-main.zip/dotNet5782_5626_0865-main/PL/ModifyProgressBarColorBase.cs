﻿using System;

namespace PL
{
    public static class ModifyProgressBarColorBase
    {

        private static void SendMessage(object handle, int v, IntPtr state, IntPtr zero)
        {
            throw new NotImplementedException();
        }
    }
}